﻿Public Class PropSeedFile

    Public lstBECAuthors As List(Of String) = New List(Of String)()

    Public lstProjects As List(Of String) = New List(Of String)()

End Class
