﻿Public Class RoutingSequence_Assembly

    Public partNumber As String = String.Empty

    Public massItem As String = String.Empty

    Public m2mFSource As String = String.Empty

    Public pmi As String = String.Empty

    Public projectName As String = String.Empty

    Public title As String = String.Empty

    Public filePath As String = String.Empty

    Public lastAuthor As String = String.Empty

    Public floc As String = String.Empty

    Public fbin As String = String.Empty

    Public qAQC As String = String.Empty

    Public quantity As String = String.Empty

End Class
