﻿Public Class M2MDataModel

    Public M2Mdescript As String = String.Empty
    Public M2Mmeasure As String = String.Empty
    Public M2Msource As String = String.Empty
    Public M2Mvendorname As String = String.Empty
    Public M2Mkeywords As String = String.Empty
    Public M2Mpartno As String = String.Empty
    Public commentformate As String = String.Empty

    Public M2Mflocation As String = String.Empty
    Public M2MFbin As String = String.Empty
End Class
