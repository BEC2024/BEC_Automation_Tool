﻿Public Class MTR_Report
    Public i As Integer
    Public excelFilePath As String
    Public dir As String
    Public files As ArrayList

    Public PartName1 As String
    Public Category2 As String
    Public interpartcopies3 As String
    Public partcopies4 As String
    Public Dash5 As String
    Public ExistFeatures6 As String
    Public MatingParts7 As String
    Public Environment8 As String
    Public Geometry9 As String
    Public UpdateOnFileSave10 As String
    Public ConstrainedFeatures11 As String
    Public UnusedFeatures12 As String
    Public Adjustable13 As String
    Public HardwarePartBox14 As String
    Public author15 As String
    Public date16 As Date

End Class
