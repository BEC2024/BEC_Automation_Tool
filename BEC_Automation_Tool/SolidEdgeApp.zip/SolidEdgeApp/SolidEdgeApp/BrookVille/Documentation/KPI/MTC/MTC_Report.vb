﻿Public Class MTC_Report
    Public excelFilePath As String
    Public dir As String
    Public files As ArrayList
    Public i As Integer

    Public category As String
    Public partName1 As String
    Public partNumberMatch2 As String
    Public revisonlevel3 As String
    Public AuthorName4 As String
    Public projectName5 As String
    Public revisoncorrect6 As String
    Public documentNumber7 As String
    Public AuthorName8 As String

    Public DashInUnusedFiled9 As String
    Public m2mDiscriptionMatch10 As String
    Public uomsMatch11 As String
    Public interface12 As String
    Public interpartcopies13 As String
    Public partcopies14 As String
    Public brokefile15 As String
    Public adjustable16 As String
    Public Matl_spec17 As String
    Public MaterialUsed18 As String
    Public RemovedUnusedFeatures19 As String
    Public ASTMminimum20 As String
    Public FlatPattern21 As String
    Public HoleToolUse22 As String
    Public componentName23 As String
    Public VirtualThread24 As String
    Public defineFeatures25 As String
    Public suppressedFeature26 As String
    Public vendorPartNumber27 As String
    Public HardwareParts28 As String
    Public m2mSourceMarked29 As String
    Public SEstatus30 As String
    Public date31 As Date
End Class
