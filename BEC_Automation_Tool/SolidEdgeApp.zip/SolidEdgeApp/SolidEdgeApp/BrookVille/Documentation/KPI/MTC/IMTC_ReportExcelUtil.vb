﻿Public Interface IMTC_ReportExcelUtil
    Sub Assembly(mtcObj As MTC_Report)
    Sub Baseline(mtcObj As MTC_Report)
    Sub Electrical(mtcObj As MTC_Report)
    Sub KillProcess()
    Sub MTCReport(mtcObj As MTC_Report)
    Sub Part(mtcObj As MTC_Report)
    Sub Row1Data(mtcObj As MTC_Report)
    Sub Sheetmetal(mtcObj As MTC_Report)
    Sub CreteMTCExce(mtcObj As MTC_Report)

End Interface
