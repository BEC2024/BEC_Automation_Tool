﻿Public Class CommonReport
    'Public revisonlevel3 As String
    'Public revisoncorrect6 As String
    Public excelFilePath As String
    Public dir As String
    Public files As ArrayList
    Public MTCfiles As ArrayList
    Public MTRfiles As ArrayList
    Public Pendingfiles As ArrayList
    Public i As Integer

    Public fileName0 As String

    Public partName1 As String
    Public category2 As String

    Public AuthorName3 As String
    Public projectName4 As String
    Public partNumberMatch5 As String
    Public documentNumber6 As String
    Public AuthorName7 As String
    Public DashInUnusedFiled8 As String
    Public m2mDiscriptionMatch9 As String
    Public uomsMatch10 As String
    Public interface11 As String
    Public interpartcopies12 As String
    Public partcopies13 As String
    Public brokefile14 As String
    Public adjustable15 As String
    Public Matl_spec16 As String
    Public MaterialUsed17 As String
    Public RemovedUnusedFeatures18 As String
    Public ASTMminimum19 As String
    Public FlatPattern20 As String
    Public HoleToolUse21 As String

    Public VirtualThread22 As String
    Public defineFeatures23 As String
    Public suppressedFeature24 As String
    Public vendorPartNumber25 As String
    Public HardwareParts26 As String
    Public m2mSourceMarked27 As String
    Public SEstatus28 As String

    Public ExistFeatures29 As String
    Public MatingParts30 As String
    Public Environment31 As String
    Public Geometry32 As String
    Public UpdateOnFileSave33 As String
    Public ConstrainedFeatures34 As String
    Public UnusedFeatures12 As String
    Public AllFeaturesRemoved35 As String
    Public HardwarePartBox36 As String





    Public date38 As Date
    Public lastModifiedDate39 As String

    'mannual questions
    Public C_RefPartOccurrenceProp40 As String
    Public C_AssemblyFeatures41 As String
    Public C_ModelPreview42 As String
    Public C_PartConstraint43 As String

    Public C_Material_Spec_Field44 As String
    Public C_MassAndDensity_Update45 As String
    Public C_Bend_Radius_Update46 As String
    Public C_FlatPattern_Update47 As String


    Public C_HardwareInstancesAndStackups48 As String
    Public C_DimensionalGeometry_Match_For_ALL49 As String
    Public C_DimensionalGeometry_Match50 As String
    Public C_suppressedUnusedFeatures51 As String

    Public C_ChildComponentsFullyConstrained52 As String
    Public C_SimplifiedAssemblyModel53 As String
    Public C_ChildPartOccurrenceProperties54 As String
    Public C_VendorMaterialData55 As String
    Public C_BaselineMassAndDensityUpdate56 As String
    Public C_PMI_Instruction57 As String
    Public C_BinderData58 As String
    Public C_TerminalAssigned59 As String
    Public C_ReferencePlanes60 As String


    Public R_ConstrainedRefPlane61 As String
    Public R_FullyConstrained62 As String
    Public R_FullyConstrainedAndGround63 As String
    Public R_ProperConstrained64 As String
    Public R_NeedSimplified65 As String
    Public R_PreviewModelGEE66 As String
    Public R_WeightMass67 As String
    Public R_OccurrenceProperties68 As String
    Public R_PatternsWithinPatterns69 As String
    Public R_ExternallySuppliedModels70 As String
    Public R_holePatterns71 As String

    Public R_HoleDiameters72 As String
    Public R_HoleClearances73 As String
    Public R_HoleDistance74 As String
    Public R_PartLineupWithMatingParts75 As String
    Public R_FITS_In_MatingParts76 As String
    Public R_Density77 As String
    Public R_Material As String
    Public R_UnusedSketches78 As String
    Public R_linkSketches79 As String
    Public R_BinderProcess80 As String
    Public R_BendRadius81 As String


End Class
