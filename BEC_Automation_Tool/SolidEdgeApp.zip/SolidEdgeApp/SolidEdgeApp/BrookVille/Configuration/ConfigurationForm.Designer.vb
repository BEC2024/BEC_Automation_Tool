﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class ConfigurationForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TextBoxM2mFile = New System.Windows.Forms.TextBox()
        Me.btnBrowseM2MFile = New System.Windows.Forms.Button()
        Me.btnBrowsePropseedFile = New System.Windows.Forms.Button()
        Me.TextBoxPropseedFile = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.btnBrowseAuthorFile = New System.Windows.Forms.Button()
        Me.TextBoxAuthorFile = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.lblDirectoryLocation = New System.Windows.Forms.Label()
        Me.btnBrowseVirtualAssemblyDirectoryPath = New System.Windows.Forms.Button()
        Me.txtVirtualAssemblyOutputDirPath = New System.Windows.Forms.TextBox()
        Me.lblExcelPath = New System.Windows.Forms.Label()
        Me.btnBrowseBECMaterialExcel = New System.Windows.Forms.Button()
        Me.txtBecMaterialExcelPath = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.btnBrowseInterferenceExcludeMaterialExcelPath = New System.Windows.Forms.Button()
        Me.txtInterferenceExcludeMaterialExcelPath = New System.Windows.Forms.TextBox()
        Me.BtnBrowseBaselineDirPath = New System.Windows.Forms.Button()
        Me.txtBaseLineDirectoryPath = New System.Windows.Forms.TextBox()
        Me.lblBaseLineDirectoryPath = New System.Windows.Forms.Label()
        Me.BtnBrowseMtcMtrExportDir = New System.Windows.Forms.Button()
        Me.txtMtcMtrReportExportDirLocation = New System.Windows.Forms.TextBox()
        Me.lblExportDirectoryLocation = New System.Windows.Forms.Label()
        Me.btnRawMaterialEstimationReportDirPath = New System.Windows.Forms.Button()
        Me.txtRawMaterialEstimationReportDirPath = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.FolderBrowserDialog1 = New System.Windows.Forms.FolderBrowserDialog()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.btnBrowseRawMaterialBomExcelPath = New System.Windows.Forms.Button()
        Me.txtRawMaterialBomExcelPath = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.BtnBrowseSolidEdgePartTemplateDirectory = New System.Windows.Forms.Button()
        Me.TxtSolidEdgePartsTemplateDirectory = New System.Windows.Forms.TextBox()
        Me.btnBrowseRoutingSequenceOutputDirectory = New System.Windows.Forms.Button()
        Me.txtRoutingSequenceOutputDirectory = New System.Windows.Forms.TextBox()
        Me.lblDir = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.txtLogOutputDirectory = New System.Windows.Forms.TextBox()
        Me.lblLogOutputDir = New System.Windows.Forms.Label()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.lblEmployeesExcelPath = New System.Windows.Forms.Label()
        Me.lblMTRExcelPath = New System.Windows.Forms.Label()
        Me.txtMTRExcelPath = New System.Windows.Forms.TextBox()
        Me.btnBrowseMTRExcelPath = New System.Windows.Forms.Button()
        Me.lblMTCExcelPath = New System.Windows.Forms.Label()
        Me.txtMTCExcelPath = New System.Windows.Forms.TextBox()
        Me.btnBrowseMTCExcelPath = New System.Windows.Forms.Button()
        Me.btnBrowseRoutingSequenceExcelPath = New System.Windows.Forms.Button()
        Me.txtRoutingSequenceExcelPath = New System.Windows.Forms.TextBox()
        Me.lblRoutingSequenceExcelPath = New System.Windows.Forms.Label()
        Me.TableLayoutPanel5 = New System.Windows.Forms.TableLayoutPanel()
        Me.TableLayoutPanel6 = New System.Windows.Forms.TableLayoutPanel()
        Me.TableLayoutPanel7 = New System.Windows.Forms.TableLayoutPanel()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.TableLayoutPanel3 = New System.Windows.Forms.TableLayoutPanel()
        Me.BtnChangeConfig1 = New System.Windows.Forms.Button()
        Me.ChkAutoSaveAuthor = New System.Windows.Forms.CheckBox()
        Me.txtEmployeeExcelPath = New System.Windows.Forms.TextBox()
        Me.btnEmployeeExcelPath = New System.Windows.Forms.Button()
        Me.btn_login = New System.Windows.Forms.Button()
        Me.txt_password = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.TableLayoutPanel4 = New System.Windows.Forms.TableLayoutPanel()
        Me.TableLayoutPanel8 = New System.Windows.Forms.TableLayoutPanel()
        Me.BtnConfigChange2 = New System.Windows.Forms.Button()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.TableLayoutPanel5.SuspendLayout()
        Me.TableLayoutPanel6.SuspendLayout()
        Me.TableLayoutPanel7.SuspendLayout()
        Me.TableLayoutPanel3.SuspendLayout()
        Me.TableLayoutPanel4.SuspendLayout()
        Me.TableLayoutPanel8.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(3, 17)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(56, 15)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "M2M File"
        '
        'TextBoxM2mFile
        '
        Me.TextBoxM2mFile.Location = New System.Drawing.Point(298, 13)
        Me.TextBoxM2mFile.Name = "TextBoxM2mFile"
        Me.TextBoxM2mFile.Size = New System.Drawing.Size(463, 23)
        Me.TextBoxM2mFile.TabIndex = 1
        '
        'btnBrowseM2MFile
        '
        Me.btnBrowseM2MFile.Location = New System.Drawing.Point(824, 13)
        Me.btnBrowseM2MFile.Name = "btnBrowseM2MFile"
        Me.btnBrowseM2MFile.Size = New System.Drawing.Size(100, 24)
        Me.btnBrowseM2MFile.TabIndex = 2
        Me.btnBrowseM2MFile.Text = "Browse"
        Me.btnBrowseM2MFile.UseVisualStyleBackColor = True
        '
        'btnBrowsePropseedFile
        '
        Me.btnBrowsePropseedFile.Location = New System.Drawing.Point(824, 43)
        Me.btnBrowsePropseedFile.Name = "btnBrowsePropseedFile"
        Me.btnBrowsePropseedFile.Size = New System.Drawing.Size(100, 28)
        Me.btnBrowsePropseedFile.TabIndex = 5
        Me.btnBrowsePropseedFile.Text = "Browse"
        Me.btnBrowsePropseedFile.UseVisualStyleBackColor = True
        '
        'TextBoxPropseedFile
        '
        Me.TextBoxPropseedFile.Location = New System.Drawing.Point(298, 43)
        Me.TextBoxPropseedFile.Name = "TextBoxPropseedFile"
        Me.TextBoxPropseedFile.Size = New System.Drawing.Size(463, 23)
        Me.TextBoxPropseedFile.TabIndex = 4
        '
        'Label2
        '
        Me.Label2.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(3, 49)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(77, 15)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Propseed File"
        '
        'btnBrowseAuthorFile
        '
        Me.btnBrowseAuthorFile.Location = New System.Drawing.Point(19, 17)
        Me.btnBrowseAuthorFile.Name = "btnBrowseAuthorFile"
        Me.btnBrowseAuthorFile.Size = New System.Drawing.Size(10, 8)
        Me.btnBrowseAuthorFile.TabIndex = 8
        Me.btnBrowseAuthorFile.Text = "Browse"
        Me.btnBrowseAuthorFile.UseVisualStyleBackColor = True
        Me.btnBrowseAuthorFile.Visible = False
        '
        'TextBoxAuthorFile
        '
        Me.TextBoxAuthorFile.Location = New System.Drawing.Point(3, 17)
        Me.TextBoxAuthorFile.Name = "TextBoxAuthorFile"
        Me.TextBoxAuthorFile.Size = New System.Drawing.Size(10, 23)
        Me.TextBoxAuthorFile.TabIndex = 7
        Me.TextBoxAuthorFile.Visible = False
        '
        'Label3
        '
        Me.Label3.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(3, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(10, 14)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "Author File"
        Me.Label3.Visible = False
        '
        'lblDirectoryLocation
        '
        Me.lblDirectoryLocation.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lblDirectoryLocation.AutoSize = True
        Me.lblDirectoryLocation.Location = New System.Drawing.Point(3, 487)
        Me.lblDirectoryLocation.Name = "lblDirectoryLocation"
        Me.lblDirectoryLocation.Size = New System.Drawing.Size(187, 15)
        Me.lblDirectoryLocation.TabIndex = 28
        Me.lblDirectoryLocation.Text = "Virtual Assembly Output Directory"
        Me.lblDirectoryLocation.Visible = False
        '
        'btnBrowseVirtualAssemblyDirectoryPath
        '
        Me.btnBrowseVirtualAssemblyDirectoryPath.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnBrowseVirtualAssemblyDirectoryPath.Location = New System.Drawing.Point(824, 483)
        Me.btnBrowseVirtualAssemblyDirectoryPath.Name = "btnBrowseVirtualAssemblyDirectoryPath"
        Me.btnBrowseVirtualAssemblyDirectoryPath.Size = New System.Drawing.Size(100, 24)
        Me.btnBrowseVirtualAssemblyDirectoryPath.TabIndex = 30
        Me.btnBrowseVirtualAssemblyDirectoryPath.Text = "Browse "
        Me.btnBrowseVirtualAssemblyDirectoryPath.UseVisualStyleBackColor = True
        Me.btnBrowseVirtualAssemblyDirectoryPath.Visible = False
        '
        'txtVirtualAssemblyOutputDirPath
        '
        Me.txtVirtualAssemblyOutputDirPath.Location = New System.Drawing.Point(298, 483)
        Me.txtVirtualAssemblyOutputDirPath.Name = "txtVirtualAssemblyOutputDirPath"
        Me.txtVirtualAssemblyOutputDirPath.Size = New System.Drawing.Size(463, 23)
        Me.txtVirtualAssemblyOutputDirPath.TabIndex = 29
        Me.txtVirtualAssemblyOutputDirPath.Visible = False
        '
        'lblExcelPath
        '
        Me.lblExcelPath.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lblExcelPath.AutoSize = True
        Me.lblExcelPath.Location = New System.Drawing.Point(3, 83)
        Me.lblExcelPath.Name = "lblExcelPath"
        Me.lblExcelPath.Size = New System.Drawing.Size(131, 15)
        Me.lblExcelPath.TabIndex = 31
        Me.lblExcelPath.Text = "BEC Material Excel Path"
        '
        'btnBrowseBECMaterialExcel
        '
        Me.btnBrowseBECMaterialExcel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnBrowseBECMaterialExcel.Location = New System.Drawing.Point(824, 77)
        Me.btnBrowseBECMaterialExcel.Name = "btnBrowseBECMaterialExcel"
        Me.btnBrowseBECMaterialExcel.Size = New System.Drawing.Size(100, 26)
        Me.btnBrowseBECMaterialExcel.TabIndex = 33
        Me.btnBrowseBECMaterialExcel.Text = "Browse"
        Me.btnBrowseBECMaterialExcel.UseVisualStyleBackColor = True
        '
        'txtBecMaterialExcelPath
        '
        Me.txtBecMaterialExcelPath.Location = New System.Drawing.Point(298, 77)
        Me.txtBecMaterialExcelPath.Name = "txtBecMaterialExcelPath"
        Me.txtBecMaterialExcelPath.Size = New System.Drawing.Size(463, 23)
        Me.txtBecMaterialExcelPath.TabIndex = 32
        '
        'Label4
        '
        Me.Label4.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(3, 151)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(217, 15)
        Me.Label4.TabIndex = 42
        Me.Label4.Text = "Interference Exclude Material Excel Path"
        '
        'btnBrowseInterferenceExcludeMaterialExcelPath
        '
        Me.btnBrowseInterferenceExcludeMaterialExcelPath.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnBrowseInterferenceExcludeMaterialExcelPath.Location = New System.Drawing.Point(824, 145)
        Me.btnBrowseInterferenceExcludeMaterialExcelPath.Name = "btnBrowseInterferenceExcludeMaterialExcelPath"
        Me.btnBrowseInterferenceExcludeMaterialExcelPath.Size = New System.Drawing.Size(100, 28)
        Me.btnBrowseInterferenceExcludeMaterialExcelPath.TabIndex = 44
        Me.btnBrowseInterferenceExcludeMaterialExcelPath.Text = "Browse"
        Me.btnBrowseInterferenceExcludeMaterialExcelPath.UseVisualStyleBackColor = True
        '
        'txtInterferenceExcludeMaterialExcelPath
        '
        Me.txtInterferenceExcludeMaterialExcelPath.Location = New System.Drawing.Point(298, 145)
        Me.txtInterferenceExcludeMaterialExcelPath.Name = "txtInterferenceExcludeMaterialExcelPath"
        Me.txtInterferenceExcludeMaterialExcelPath.Size = New System.Drawing.Size(463, 23)
        Me.txtInterferenceExcludeMaterialExcelPath.TabIndex = 43
        '
        'BtnBrowseBaselineDirPath
        '
        Me.BtnBrowseBaselineDirPath.Location = New System.Drawing.Point(824, 179)
        Me.BtnBrowseBaselineDirPath.Name = "BtnBrowseBaselineDirPath"
        Me.BtnBrowseBaselineDirPath.Size = New System.Drawing.Size(100, 26)
        Me.BtnBrowseBaselineDirPath.TabIndex = 47
        Me.BtnBrowseBaselineDirPath.Text = "Browse"
        Me.BtnBrowseBaselineDirPath.UseVisualStyleBackColor = True
        '
        'txtBaseLineDirectoryPath
        '
        Me.txtBaseLineDirectoryPath.Location = New System.Drawing.Point(298, 179)
        Me.txtBaseLineDirectoryPath.Name = "txtBaseLineDirectoryPath"
        Me.txtBaseLineDirectoryPath.Size = New System.Drawing.Size(463, 23)
        Me.txtBaseLineDirectoryPath.TabIndex = 46
        '
        'lblBaseLineDirectoryPath
        '
        Me.lblBaseLineDirectoryPath.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lblBaseLineDirectoryPath.AutoSize = True
        Me.lblBaseLineDirectoryPath.Location = New System.Drawing.Point(3, 185)
        Me.lblBaseLineDirectoryPath.Name = "lblBaseLineDirectoryPath"
        Me.lblBaseLineDirectoryPath.Size = New System.Drawing.Size(128, 15)
        Me.lblBaseLineDirectoryPath.TabIndex = 45
        Me.lblBaseLineDirectoryPath.Text = "Baseline Directory Path"
        '
        'BtnBrowseMtcMtrExportDir
        '
        Me.BtnBrowseMtcMtrExportDir.Location = New System.Drawing.Point(824, 383)
        Me.BtnBrowseMtcMtrExportDir.Name = "BtnBrowseMtcMtrExportDir"
        Me.BtnBrowseMtcMtrExportDir.Size = New System.Drawing.Size(100, 27)
        Me.BtnBrowseMtcMtrExportDir.TabIndex = 50
        Me.BtnBrowseMtcMtrExportDir.Text = "Browse"
        Me.BtnBrowseMtcMtrExportDir.UseVisualStyleBackColor = True
        '
        'txtMtcMtrReportExportDirLocation
        '
        Me.txtMtcMtrReportExportDirLocation.Location = New System.Drawing.Point(298, 383)
        Me.txtMtcMtrReportExportDirLocation.Name = "txtMtcMtrReportExportDirLocation"
        Me.txtMtcMtrReportExportDirLocation.Size = New System.Drawing.Size(463, 23)
        Me.txtMtcMtrReportExportDirLocation.TabIndex = 49
        '
        'lblExportDirectoryLocation
        '
        Me.lblExportDirectoryLocation.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lblExportDirectoryLocation.AutoSize = True
        Me.lblExportDirectoryLocation.Location = New System.Drawing.Point(3, 389)
        Me.lblExportDirectoryLocation.Name = "lblExportDirectoryLocation"
        Me.lblExportDirectoryLocation.Size = New System.Drawing.Size(123, 15)
        Me.lblExportDirectoryLocation.TabIndex = 48
        Me.lblExportDirectoryLocation.Text = "MTC Output Directory"
        '
        'btnRawMaterialEstimationReportDirPath
        '
        Me.btnRawMaterialEstimationReportDirPath.Location = New System.Drawing.Point(824, 451)
        Me.btnRawMaterialEstimationReportDirPath.Name = "btnRawMaterialEstimationReportDirPath"
        Me.btnRawMaterialEstimationReportDirPath.Size = New System.Drawing.Size(100, 24)
        Me.btnRawMaterialEstimationReportDirPath.TabIndex = 53
        Me.btnRawMaterialEstimationReportDirPath.Text = "Browse"
        Me.btnRawMaterialEstimationReportDirPath.UseVisualStyleBackColor = True
        Me.btnRawMaterialEstimationReportDirPath.Visible = False
        '
        'txtRawMaterialEstimationReportDirPath
        '
        Me.txtRawMaterialEstimationReportDirPath.Location = New System.Drawing.Point(298, 451)
        Me.txtRawMaterialEstimationReportDirPath.Name = "txtRawMaterialEstimationReportDirPath"
        Me.txtRawMaterialEstimationReportDirPath.Size = New System.Drawing.Size(463, 23)
        Me.txtRawMaterialEstimationReportDirPath.TabIndex = 52
        Me.txtRawMaterialEstimationReportDirPath.Visible = False
        '
        'Label5
        '
        Me.Label5.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(3, 456)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(167, 15)
        Me.Label5.TabIndex = 51
        Me.Label5.Text = "Raw Material Output Directory"
        Me.Label5.Visible = False
        '
        'Label6
        '
        Me.Label6.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(3, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(10, 12)
        Me.Label6.TabIndex = 54
        Me.Label6.Text = "Raw Material BOM Excel Path"
        Me.Label6.Visible = False
        '
        'btnBrowseRawMaterialBomExcelPath
        '
        Me.btnBrowseRawMaterialBomExcelPath.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnBrowseRawMaterialBomExcelPath.Location = New System.Drawing.Point(19, 15)
        Me.btnBrowseRawMaterialBomExcelPath.Name = "btnBrowseRawMaterialBomExcelPath"
        Me.btnBrowseRawMaterialBomExcelPath.Size = New System.Drawing.Size(10, 6)
        Me.btnBrowseRawMaterialBomExcelPath.TabIndex = 56
        Me.btnBrowseRawMaterialBomExcelPath.Text = "Browse"
        Me.btnBrowseRawMaterialBomExcelPath.UseVisualStyleBackColor = True
        Me.btnBrowseRawMaterialBomExcelPath.Visible = False
        '
        'txtRawMaterialBomExcelPath
        '
        Me.txtRawMaterialBomExcelPath.Location = New System.Drawing.Point(3, 15)
        Me.txtRawMaterialBomExcelPath.Name = "txtRawMaterialBomExcelPath"
        Me.txtRawMaterialBomExcelPath.Size = New System.Drawing.Size(10, 23)
        Me.txtRawMaterialBomExcelPath.TabIndex = 55
        Me.txtRawMaterialBomExcelPath.Visible = False
        '
        'Label7
        '
        Me.Label7.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(3, 117)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(195, 15)
        Me.Label7.TabIndex = 105
        Me.Label7.Text = "SolidEdge Parts Templates Directory"
        '
        'BtnBrowseSolidEdgePartTemplateDirectory
        '
        Me.BtnBrowseSolidEdgePartTemplateDirectory.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnBrowseSolidEdgePartTemplateDirectory.Location = New System.Drawing.Point(824, 111)
        Me.BtnBrowseSolidEdgePartTemplateDirectory.Name = "BtnBrowseSolidEdgePartTemplateDirectory"
        Me.BtnBrowseSolidEdgePartTemplateDirectory.Size = New System.Drawing.Size(100, 26)
        Me.BtnBrowseSolidEdgePartTemplateDirectory.TabIndex = 107
        Me.BtnBrowseSolidEdgePartTemplateDirectory.Text = "Browse"
        Me.BtnBrowseSolidEdgePartTemplateDirectory.UseVisualStyleBackColor = True
        '
        'TxtSolidEdgePartsTemplateDirectory
        '
        Me.TxtSolidEdgePartsTemplateDirectory.Location = New System.Drawing.Point(298, 111)
        Me.TxtSolidEdgePartsTemplateDirectory.Name = "TxtSolidEdgePartsTemplateDirectory"
        Me.TxtSolidEdgePartsTemplateDirectory.Size = New System.Drawing.Size(463, 23)
        Me.TxtSolidEdgePartsTemplateDirectory.TabIndex = 106
        '
        'btnBrowseRoutingSequenceOutputDirectory
        '
        Me.btnBrowseRoutingSequenceOutputDirectory.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBrowseRoutingSequenceOutputDirectory.Location = New System.Drawing.Point(824, 417)
        Me.btnBrowseRoutingSequenceOutputDirectory.Name = "btnBrowseRoutingSequenceOutputDirectory"
        Me.btnBrowseRoutingSequenceOutputDirectory.Size = New System.Drawing.Size(100, 28)
        Me.btnBrowseRoutingSequenceOutputDirectory.TabIndex = 110
        Me.btnBrowseRoutingSequenceOutputDirectory.Text = "Browse"
        Me.btnBrowseRoutingSequenceOutputDirectory.UseVisualStyleBackColor = True
        '
        'txtRoutingSequenceOutputDirectory
        '
        Me.txtRoutingSequenceOutputDirectory.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtRoutingSequenceOutputDirectory.Location = New System.Drawing.Point(298, 417)
        Me.txtRoutingSequenceOutputDirectory.Name = "txtRoutingSequenceOutputDirectory"
        Me.txtRoutingSequenceOutputDirectory.Size = New System.Drawing.Size(463, 23)
        Me.txtRoutingSequenceOutputDirectory.TabIndex = 109
        '
        'lblDir
        '
        Me.lblDir.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lblDir.AutoSize = True
        Me.lblDir.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDir.Location = New System.Drawing.Point(3, 423)
        Me.lblDir.Name = "lblDir"
        Me.lblDir.Size = New System.Drawing.Size(195, 15)
        Me.lblDir.TabIndex = 108
        Me.lblDir.Text = "Routing Sequence Output Directory"
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(824, 349)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(100, 24)
        Me.Button1.TabIndex = 113
        Me.Button1.Text = "Browse"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'txtLogOutputDirectory
        '
        Me.txtLogOutputDirectory.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtLogOutputDirectory.Location = New System.Drawing.Point(298, 349)
        Me.txtLogOutputDirectory.Name = "txtLogOutputDirectory"
        Me.txtLogOutputDirectory.Size = New System.Drawing.Size(463, 23)
        Me.txtLogOutputDirectory.TabIndex = 112
        '
        'lblLogOutputDir
        '
        Me.lblLogOutputDir.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lblLogOutputDir.AutoSize = True
        Me.lblLogOutputDir.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblLogOutputDir.Location = New System.Drawing.Point(3, 355)
        Me.lblLogOutputDir.Name = "lblLogOutputDir"
        Me.lblLogOutputDir.Size = New System.Drawing.Size(119, 15)
        Me.lblLogOutputDir.TabIndex = 111
        Me.lblLogOutputDir.Text = "Log Output Directory"
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 4
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 295.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 526.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 203.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 38.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.TextBoxM2mFile, 1, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.lblEmployeesExcelPath, 0, 10)
        Me.TableLayoutPanel1.Controls.Add(Me.btnBrowseM2MFile, 2, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Label2, 0, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBoxPropseedFile, 1, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.btnBrowsePropseedFile, 2, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.Label1, 0, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.lblMTRExcelPath, 0, 16)
        Me.TableLayoutPanel1.Controls.Add(Me.txtMTRExcelPath, 1, 16)
        Me.TableLayoutPanel1.Controls.Add(Me.btnBrowseMTRExcelPath, 2, 16)
        Me.TableLayoutPanel1.Controls.Add(Me.lblDirectoryLocation, 0, 15)
        Me.TableLayoutPanel1.Controls.Add(Me.txtVirtualAssemblyOutputDirPath, 1, 15)
        Me.TableLayoutPanel1.Controls.Add(Me.btnBrowseVirtualAssemblyDirectoryPath, 2, 15)
        Me.TableLayoutPanel1.Controls.Add(Me.Label5, 0, 14)
        Me.TableLayoutPanel1.Controls.Add(Me.txtRawMaterialEstimationReportDirPath, 1, 14)
        Me.TableLayoutPanel1.Controls.Add(Me.btnRawMaterialEstimationReportDirPath, 2, 14)
        Me.TableLayoutPanel1.Controls.Add(Me.lblDir, 0, 13)
        Me.TableLayoutPanel1.Controls.Add(Me.txtRoutingSequenceOutputDirectory, 1, 13)
        Me.TableLayoutPanel1.Controls.Add(Me.btnBrowseRoutingSequenceOutputDirectory, 2, 13)
        Me.TableLayoutPanel1.Controls.Add(Me.lblExportDirectoryLocation, 0, 12)
        Me.TableLayoutPanel1.Controls.Add(Me.txtMtcMtrReportExportDirLocation, 1, 12)
        Me.TableLayoutPanel1.Controls.Add(Me.BtnBrowseMtcMtrExportDir, 2, 12)
        Me.TableLayoutPanel1.Controls.Add(Me.lblExcelPath, 0, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.txtBecMaterialExcelPath, 1, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.btnBrowseBECMaterialExcel, 2, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.BtnBrowseSolidEdgePartTemplateDirectory, 2, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.TxtSolidEdgePartsTemplateDirectory, 1, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.Label7, 0, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.Label4, 0, 5)
        Me.TableLayoutPanel1.Controls.Add(Me.txtInterferenceExcludeMaterialExcelPath, 1, 5)
        Me.TableLayoutPanel1.Controls.Add(Me.btnBrowseInterferenceExcludeMaterialExcelPath, 2, 5)
        Me.TableLayoutPanel1.Controls.Add(Me.BtnBrowseBaselineDirPath, 2, 6)
        Me.TableLayoutPanel1.Controls.Add(Me.txtBaseLineDirectoryPath, 1, 6)
        Me.TableLayoutPanel1.Controls.Add(Me.lblBaseLineDirectoryPath, 0, 6)
        Me.TableLayoutPanel1.Controls.Add(Me.lblMTCExcelPath, 0, 7)
        Me.TableLayoutPanel1.Controls.Add(Me.txtMTCExcelPath, 1, 7)
        Me.TableLayoutPanel1.Controls.Add(Me.btnBrowseMTCExcelPath, 2, 7)
        Me.TableLayoutPanel1.Controls.Add(Me.btnBrowseRoutingSequenceExcelPath, 2, 8)
        Me.TableLayoutPanel1.Controls.Add(Me.txtRoutingSequenceExcelPath, 1, 8)
        Me.TableLayoutPanel1.Controls.Add(Me.lblRoutingSequenceExcelPath, 0, 8)
        Me.TableLayoutPanel1.Controls.Add(Me.TableLayoutPanel5, 3, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.TableLayoutPanel6, 3, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.TableLayoutPanel7, 2, 17)
        Me.TableLayoutPanel1.Controls.Add(Me.lblLogOutputDir, 0, 11)
        Me.TableLayoutPanel1.Controls.Add(Me.TableLayoutPanel3, 1, 17)
        Me.TableLayoutPanel1.Controls.Add(Me.ChkAutoSaveAuthor, 0, 9)
        Me.TableLayoutPanel1.Controls.Add(Me.txtLogOutputDirectory, 1, 11)
        Me.TableLayoutPanel1.Controls.Add(Me.txtEmployeeExcelPath, 1, 10)
        Me.TableLayoutPanel1.Controls.Add(Me.Button1, 2, 11)
        Me.TableLayoutPanel1.Controls.Add(Me.btnEmployeeExcelPath, 2, 10)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Enabled = False
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 18
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 10.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 16.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(1062, 591)
        Me.TableLayoutPanel1.TabIndex = 114
        '
        'lblEmployeesExcelPath
        '
        Me.lblEmployeesExcelPath.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lblEmployeesExcelPath.AutoSize = True
        Me.lblEmployeesExcelPath.Location = New System.Drawing.Point(3, 321)
        Me.lblEmployeesExcelPath.Name = "lblEmployeesExcelPath"
        Me.lblEmployeesExcelPath.Size = New System.Drawing.Size(119, 15)
        Me.lblEmployeesExcelPath.TabIndex = 127
        Me.lblEmployeesExcelPath.Text = "Employee Excel Path "
        '
        'lblMTRExcelPath
        '
        Me.lblMTRExcelPath.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lblMTRExcelPath.AutoSize = True
        Me.lblMTRExcelPath.Location = New System.Drawing.Point(3, 519)
        Me.lblMTRExcelPath.Name = "lblMTRExcelPath"
        Me.lblMTRExcelPath.Size = New System.Drawing.Size(139, 15)
        Me.lblMTRExcelPath.TabIndex = 117
        Me.lblMTRExcelPath.Text = "MTR Excel Template Path"
        Me.lblMTRExcelPath.Visible = False
        '
        'txtMTRExcelPath
        '
        Me.txtMTRExcelPath.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtMTRExcelPath.Location = New System.Drawing.Point(298, 515)
        Me.txtMTRExcelPath.Name = "txtMTRExcelPath"
        Me.txtMTRExcelPath.Size = New System.Drawing.Size(463, 23)
        Me.txtMTRExcelPath.TabIndex = 120
        Me.txtMTRExcelPath.Visible = False
        '
        'btnBrowseMTRExcelPath
        '
        Me.btnBrowseMTRExcelPath.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnBrowseMTRExcelPath.Location = New System.Drawing.Point(824, 513)
        Me.btnBrowseMTRExcelPath.Name = "btnBrowseMTRExcelPath"
        Me.btnBrowseMTRExcelPath.Size = New System.Drawing.Size(100, 26)
        Me.btnBrowseMTRExcelPath.TabIndex = 123
        Me.btnBrowseMTRExcelPath.Text = "Browse"
        Me.btnBrowseMTRExcelPath.UseVisualStyleBackColor = True
        Me.btnBrowseMTRExcelPath.Visible = False
        '
        'lblMTCExcelPath
        '
        Me.lblMTCExcelPath.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lblMTCExcelPath.AutoSize = True
        Me.lblMTCExcelPath.Location = New System.Drawing.Point(3, 219)
        Me.lblMTCExcelPath.Name = "lblMTCExcelPath"
        Me.lblMTCExcelPath.Size = New System.Drawing.Size(139, 15)
        Me.lblMTCExcelPath.TabIndex = 116
        Me.lblMTCExcelPath.Text = "MTC Excel Template Path"
        '
        'txtMTCExcelPath
        '
        Me.txtMTCExcelPath.Location = New System.Drawing.Point(298, 213)
        Me.txtMTCExcelPath.Name = "txtMTCExcelPath"
        Me.txtMTCExcelPath.Size = New System.Drawing.Size(463, 23)
        Me.txtMTCExcelPath.TabIndex = 119
        '
        'btnBrowseMTCExcelPath
        '
        Me.btnBrowseMTCExcelPath.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnBrowseMTCExcelPath.Location = New System.Drawing.Point(824, 213)
        Me.btnBrowseMTCExcelPath.Name = "btnBrowseMTCExcelPath"
        Me.btnBrowseMTCExcelPath.Size = New System.Drawing.Size(100, 26)
        Me.btnBrowseMTCExcelPath.TabIndex = 122
        Me.btnBrowseMTCExcelPath.Text = "Browse"
        Me.btnBrowseMTCExcelPath.UseVisualStyleBackColor = True
        '
        'btnBrowseRoutingSequenceExcelPath
        '
        Me.btnBrowseRoutingSequenceExcelPath.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnBrowseRoutingSequenceExcelPath.Location = New System.Drawing.Point(824, 247)
        Me.btnBrowseRoutingSequenceExcelPath.Name = "btnBrowseRoutingSequenceExcelPath"
        Me.btnBrowseRoutingSequenceExcelPath.Size = New System.Drawing.Size(100, 24)
        Me.btnBrowseRoutingSequenceExcelPath.TabIndex = 124
        Me.btnBrowseRoutingSequenceExcelPath.Text = "Browse"
        Me.btnBrowseRoutingSequenceExcelPath.UseVisualStyleBackColor = True
        '
        'txtRoutingSequenceExcelPath
        '
        Me.txtRoutingSequenceExcelPath.Location = New System.Drawing.Point(298, 247)
        Me.txtRoutingSequenceExcelPath.Name = "txtRoutingSequenceExcelPath"
        Me.txtRoutingSequenceExcelPath.Size = New System.Drawing.Size(463, 23)
        Me.txtRoutingSequenceExcelPath.TabIndex = 121
        '
        'lblRoutingSequenceExcelPath
        '
        Me.lblRoutingSequenceExcelPath.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lblRoutingSequenceExcelPath.AutoSize = True
        Me.lblRoutingSequenceExcelPath.Location = New System.Drawing.Point(3, 253)
        Me.lblRoutingSequenceExcelPath.Name = "lblRoutingSequenceExcelPath"
        Me.lblRoutingSequenceExcelPath.Size = New System.Drawing.Size(211, 15)
        Me.lblRoutingSequenceExcelPath.TabIndex = 118
        Me.lblRoutingSequenceExcelPath.Text = "Routing Sequence Excel Template Path"
        '
        'TableLayoutPanel5
        '
        Me.TableLayoutPanel5.ColumnCount = 2
        Me.TableLayoutPanel5.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel5.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel5.Controls.Add(Me.Label6, 0, 0)
        Me.TableLayoutPanel5.Controls.Add(Me.btnBrowseRawMaterialBomExcelPath, 1, 1)
        Me.TableLayoutPanel5.Controls.Add(Me.txtRawMaterialBomExcelPath, 0, 1)
        Me.TableLayoutPanel5.Location = New System.Drawing.Point(1027, 13)
        Me.TableLayoutPanel5.Name = "TableLayoutPanel5"
        Me.TableLayoutPanel5.RowCount = 2
        Me.TableLayoutPanel5.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel5.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel5.Size = New System.Drawing.Size(32, 24)
        Me.TableLayoutPanel5.TabIndex = 0
        '
        'TableLayoutPanel6
        '
        Me.TableLayoutPanel6.ColumnCount = 2
        Me.TableLayoutPanel6.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel6.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel6.Controls.Add(Me.Label3, 0, 0)
        Me.TableLayoutPanel6.Controls.Add(Me.TextBoxAuthorFile, 0, 1)
        Me.TableLayoutPanel6.Controls.Add(Me.btnBrowseAuthorFile, 1, 1)
        Me.TableLayoutPanel6.Location = New System.Drawing.Point(1027, 77)
        Me.TableLayoutPanel6.Name = "TableLayoutPanel6"
        Me.TableLayoutPanel6.RowCount = 2
        Me.TableLayoutPanel6.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel6.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel6.Size = New System.Drawing.Size(32, 28)
        Me.TableLayoutPanel6.TabIndex = 130
        '
        'TableLayoutPanel7
        '
        Me.TableLayoutPanel7.ColumnCount = 2
        Me.TableLayoutPanel7.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel7.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 102.0!))
        Me.TableLayoutPanel7.Controls.Add(Me.btnSave, 1, 0)
        Me.TableLayoutPanel7.Controls.Add(Me.btnClose, 0, 0)
        Me.TableLayoutPanel7.Location = New System.Drawing.Point(824, 547)
        Me.TableLayoutPanel7.Name = "TableLayoutPanel7"
        Me.TableLayoutPanel7.RowCount = 1
        Me.TableLayoutPanel7.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel7.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 41.0!))
        Me.TableLayoutPanel7.Size = New System.Drawing.Size(197, 41)
        Me.TableLayoutPanel7.TabIndex = 131
        '
        'btnSave
        '
        Me.btnSave.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.btnSave.Location = New System.Drawing.Point(100, 8)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(91, 30)
        Me.btnSave.TabIndex = 1
        Me.btnSave.Text = "Save"
        Me.btnSave.UseVisualStyleBackColor = True
        '
        'btnClose
        '
        Me.btnClose.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.btnClose.Location = New System.Drawing.Point(3, 8)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(89, 30)
        Me.btnClose.TabIndex = 0
        Me.btnClose.Text = "Close"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'TableLayoutPanel3
        '
        Me.TableLayoutPanel3.ColumnCount = 1
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel3.Controls.Add(Me.BtnChangeConfig1, 0, 0)
        Me.TableLayoutPanel3.Location = New System.Drawing.Point(298, 547)
        Me.TableLayoutPanel3.Name = "TableLayoutPanel3"
        Me.TableLayoutPanel3.RowCount = 1
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 41.0!))
        Me.TableLayoutPanel3.Size = New System.Drawing.Size(515, 41)
        Me.TableLayoutPanel3.TabIndex = 126
        '
        'BtnChangeConfig1
        '
        Me.BtnChangeConfig1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.BtnChangeConfig1.Location = New System.Drawing.Point(3, 8)
        Me.BtnChangeConfig1.Name = "BtnChangeConfig1"
        Me.BtnChangeConfig1.Size = New System.Drawing.Size(463, 30)
        Me.BtnChangeConfig1.TabIndex = 125
        Me.BtnChangeConfig1.Text = "Set Configuration Path"
        Me.BtnChangeConfig1.UseVisualStyleBackColor = True
        '
        'ChkAutoSaveAuthor
        '
        Me.ChkAutoSaveAuthor.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.ChkAutoSaveAuthor.AutoSize = True
        Me.ChkAutoSaveAuthor.Location = New System.Drawing.Point(3, 285)
        Me.ChkAutoSaveAuthor.Name = "ChkAutoSaveAuthor"
        Me.ChkAutoSaveAuthor.Size = New System.Drawing.Size(119, 19)
        Me.ChkAutoSaveAuthor.TabIndex = 133
        Me.ChkAutoSaveAuthor.Text = "Auto Save Author"
        Me.ChkAutoSaveAuthor.UseVisualStyleBackColor = True
        '
        'txtEmployeeExcelPath
        '
        Me.txtEmployeeExcelPath.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtEmployeeExcelPath.Location = New System.Drawing.Point(298, 317)
        Me.txtEmployeeExcelPath.Name = "txtEmployeeExcelPath"
        Me.txtEmployeeExcelPath.Size = New System.Drawing.Size(463, 23)
        Me.txtEmployeeExcelPath.TabIndex = 128
        '
        'btnEmployeeExcelPath
        '
        Me.btnEmployeeExcelPath.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.btnEmployeeExcelPath.Location = New System.Drawing.Point(824, 317)
        Me.btnEmployeeExcelPath.Name = "btnEmployeeExcelPath"
        Me.btnEmployeeExcelPath.Size = New System.Drawing.Size(100, 24)
        Me.btnEmployeeExcelPath.TabIndex = 129
        Me.btnEmployeeExcelPath.Text = "Browse"
        Me.btnEmployeeExcelPath.UseVisualStyleBackColor = True
        '
        'btn_login
        '
        Me.btn_login.Location = New System.Drawing.Point(148, 45)
        Me.btn_login.Name = "btn_login"
        Me.btn_login.Size = New System.Drawing.Size(57, 23)
        Me.btn_login.TabIndex = 117
        Me.btn_login.Text = "Login"
        Me.btn_login.UseVisualStyleBackColor = True
        '
        'txt_password
        '
        Me.txt_password.Location = New System.Drawing.Point(3, 45)
        Me.txt_password.Name = "txt_password"
        Me.txt_password.Size = New System.Drawing.Size(134, 23)
        Me.txt_password.TabIndex = 116
        Me.txt_password.UseSystemPasswordChar = True
        '
        'Label8
        '
        Me.Label8.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(29, 13)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(87, 15)
        Me.Label8.TabIndex = 115
        Me.Label8.Text = "Enter Password"
        '
        'TableLayoutPanel4
        '
        Me.TableLayoutPanel4.BackColor = System.Drawing.SystemColors.Control
        Me.TableLayoutPanel4.ColumnCount = 2
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 18.04878!))
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 17.92683!))
        Me.TableLayoutPanel4.Controls.Add(Me.Label8, 0, 0)
        Me.TableLayoutPanel4.Controls.Add(Me.btn_login, 1, 1)
        Me.TableLayoutPanel4.Controls.Add(Me.txt_password, 0, 1)
        Me.TableLayoutPanel4.Location = New System.Drawing.Point(1, 515)
        Me.TableLayoutPanel4.Name = "TableLayoutPanel4"
        Me.TableLayoutPanel4.RowCount = 2
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 52.5!))
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 47.5!))
        Me.TableLayoutPanel4.Size = New System.Drawing.Size(291, 80)
        Me.TableLayoutPanel4.TabIndex = 118
        '
        'TableLayoutPanel8
        '
        Me.TableLayoutPanel8.ColumnCount = 1
        Me.TableLayoutPanel8.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel8.Controls.Add(Me.BtnConfigChange2, 0, 0)
        Me.TableLayoutPanel8.Location = New System.Drawing.Point(298, 548)
        Me.TableLayoutPanel8.Name = "TableLayoutPanel8"
        Me.TableLayoutPanel8.RowCount = 1
        Me.TableLayoutPanel8.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel8.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 41.0!))
        Me.TableLayoutPanel8.Size = New System.Drawing.Size(515, 41)
        Me.TableLayoutPanel8.TabIndex = 127
        '
        'BtnConfigChange2
        '
        Me.BtnConfigChange2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.BtnConfigChange2.Location = New System.Drawing.Point(3, 8)
        Me.BtnConfigChange2.Name = "BtnConfigChange2"
        Me.BtnConfigChange2.Size = New System.Drawing.Size(463, 30)
        Me.BtnConfigChange2.TabIndex = 125
        Me.BtnConfigChange2.Text = "Set Configuration Path"
        Me.BtnConfigChange2.UseVisualStyleBackColor = True
        '
        'ConfigurationForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1062, 591)
        Me.Controls.Add(Me.TableLayoutPanel4)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Controls.Add(Me.TableLayoutPanel8)
        Me.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "ConfigurationForm"
        Me.Text = "Configuration"
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.TableLayoutPanel1.PerformLayout()
        Me.TableLayoutPanel5.ResumeLayout(False)
        Me.TableLayoutPanel5.PerformLayout()
        Me.TableLayoutPanel6.ResumeLayout(False)
        Me.TableLayoutPanel6.PerformLayout()
        Me.TableLayoutPanel7.ResumeLayout(False)
        Me.TableLayoutPanel3.ResumeLayout(False)
        Me.TableLayoutPanel4.ResumeLayout(False)
        Me.TableLayoutPanel4.PerformLayout()
        Me.TableLayoutPanel8.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents TextBoxM2mFile As TextBox
    Friend WithEvents btnBrowseM2MFile As Button
    Friend WithEvents btnBrowsePropseedFile As Button
    Friend WithEvents TextBoxPropseedFile As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents btnBrowseAuthorFile As Button
    Friend WithEvents TextBoxAuthorFile As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents lblDirectoryLocation As Label
    Friend WithEvents btnBrowseVirtualAssemblyDirectoryPath As Button
    Friend WithEvents txtVirtualAssemblyOutputDirPath As TextBox
    Friend WithEvents lblExcelPath As Label
    Friend WithEvents btnBrowseBECMaterialExcel As Button
    Friend WithEvents txtBecMaterialExcelPath As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents btnBrowseInterferenceExcludeMaterialExcelPath As Button
    Friend WithEvents txtInterferenceExcludeMaterialExcelPath As TextBox
    Friend WithEvents BtnBrowseBaselineDirPath As Button
    Friend WithEvents txtBaseLineDirectoryPath As TextBox
    Friend WithEvents lblBaseLineDirectoryPath As Label
    Friend WithEvents BtnBrowseMtcMtrExportDir As Button
    Friend WithEvents txtMtcMtrReportExportDirLocation As TextBox
    Friend WithEvents lblExportDirectoryLocation As Label
    Friend WithEvents btnRawMaterialEstimationReportDirPath As Button
    Friend WithEvents txtRawMaterialEstimationReportDirPath As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents FolderBrowserDialog1 As FolderBrowserDialog
    Friend WithEvents Label6 As Label
    Friend WithEvents btnBrowseRawMaterialBomExcelPath As Button
    Friend WithEvents txtRawMaterialBomExcelPath As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents BtnBrowseSolidEdgePartTemplateDirectory As Button
    Friend WithEvents TxtSolidEdgePartsTemplateDirectory As TextBox
    Friend WithEvents btnBrowseRoutingSequenceOutputDirectory As Button
    Friend WithEvents txtRoutingSequenceOutputDirectory As TextBox
    Friend WithEvents lblDir As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents txtLogOutputDirectory As TextBox
    Friend WithEvents lblLogOutputDir As Label
    Friend WithEvents TableLayoutPanel1 As TableLayoutPanel
    Friend WithEvents lblMTCExcelPath As Label
    Friend WithEvents txtMTCExcelPath As TextBox
    Friend WithEvents lblRoutingSequenceExcelPath As Label
    Friend WithEvents txtRoutingSequenceExcelPath As TextBox
    Friend WithEvents btnBrowseMTCExcelPath As Button
    Friend WithEvents btnBrowseRoutingSequenceExcelPath As Button
    Friend WithEvents lblMTRExcelPath As Label
    Friend WithEvents txtMTRExcelPath As TextBox
    Friend WithEvents btnBrowseMTRExcelPath As Button
    Friend WithEvents btn_login As Button
    Friend WithEvents txt_password As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents TableLayoutPanel4 As TableLayoutPanel
    Friend WithEvents lblEmployeesExcelPath As Label
    Friend WithEvents txtEmployeeExcelPath As TextBox
    Friend WithEvents btnEmployeeExcelPath As Button
    Friend WithEvents TableLayoutPanel5 As TableLayoutPanel
    Friend WithEvents TableLayoutPanel6 As TableLayoutPanel
    Friend WithEvents TableLayoutPanel7 As TableLayoutPanel
    Friend WithEvents btnSave As Button
    Friend WithEvents btnClose As Button
    Friend WithEvents TableLayoutPanel3 As TableLayoutPanel
    Friend WithEvents BtnChangeConfig1 As Button
    Friend WithEvents TableLayoutPanel8 As TableLayoutPanel
    Friend WithEvents BtnConfigChange2 As Button
    Friend WithEvents ChkAutoSaveAuthor As CheckBox
End Class
