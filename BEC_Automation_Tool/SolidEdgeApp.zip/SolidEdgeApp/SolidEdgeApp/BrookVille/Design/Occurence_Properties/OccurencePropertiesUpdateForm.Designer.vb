﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class OccurencePropertiesUpdateForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(OccurencePropertiesUpdateForm))
        Me.btnUpdateProperties = New System.Windows.Forms.Button()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.rbNo_HighLevel = New System.Windows.Forms.RadioButton()
        Me.rbYes_HighLevel = New System.Windows.Forms.RadioButton()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.rbNo_ApplyColor = New System.Windows.Forms.RadioButton()
        Me.rbYes_ApplyColor = New System.Windows.Forms.RadioButton()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.RadioButton9 = New System.Windows.Forms.RadioButton()
        Me.rbYes_PhysicalProperties = New System.Windows.Forms.RadioButton()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.rbNo_InterfernceAnalysis = New System.Windows.Forms.RadioButton()
        Me.rbYes_InterfernceAnalysis = New System.Windows.Forms.RadioButton()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.rbNo_DrawingViews = New System.Windows.Forms.RadioButton()
        Me.rbYes_DrawingViews = New System.Windows.Forms.RadioButton()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.rbNo_ReportPartList = New System.Windows.Forms.RadioButton()
        Me.rbYes_ReportPartList = New System.Windows.Forms.RadioButton()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.Panel6.SuspendLayout()
        Me.Panel5.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnUpdateProperties
        '
        Me.btnUpdateProperties.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnUpdateProperties.Location = New System.Drawing.Point(852, 551)
        Me.btnUpdateProperties.Name = "btnUpdateProperties"
        Me.btnUpdateProperties.Size = New System.Drawing.Size(199, 30)
        Me.btnUpdateProperties.TabIndex = 0
        Me.btnUpdateProperties.Text = "Update Occurence Properties"
        Me.btnUpdateProperties.UseVisualStyleBackColor = True
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 2
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 47.11246!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 52.88754!))
        Me.TableLayoutPanel1.Controls.Add(Me.Panel1, 1, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Panel6, 1, 5)
        Me.TableLayoutPanel1.Controls.Add(Me.Panel5, 1, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.Panel4, 1, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.Panel3, 1, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.Label1, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Label2, 0, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Panel2, 1, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Label3, 0, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.Label4, 0, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.Label5, 0, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.Label6, 0, 5)
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(12, 12)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 6
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(329, 210)
        Me.TableLayoutPanel1.TabIndex = 12
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.rbNo_HighLevel)
        Me.Panel1.Controls.Add(Me.rbYes_HighLevel)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(157, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(169, 29)
        Me.Panel1.TabIndex = 4
        '
        'rbNo_HighLevel
        '
        Me.rbNo_HighLevel.AutoSize = True
        Me.rbNo_HighLevel.Checked = True
        Me.rbNo_HighLevel.Location = New System.Drawing.Point(70, 4)
        Me.rbNo_HighLevel.Name = "rbNo_HighLevel"
        Me.rbNo_HighLevel.Size = New System.Drawing.Size(41, 19)
        Me.rbNo_HighLevel.TabIndex = 1
        Me.rbNo_HighLevel.TabStop = True
        Me.rbNo_HighLevel.Text = "No"
        Me.rbNo_HighLevel.UseVisualStyleBackColor = True
        '
        'rbYes_HighLevel
        '
        Me.rbYes_HighLevel.AutoSize = True
        Me.rbYes_HighLevel.Location = New System.Drawing.Point(14, 3)
        Me.rbYes_HighLevel.Name = "rbYes_HighLevel"
        Me.rbYes_HighLevel.Size = New System.Drawing.Size(42, 19)
        Me.rbYes_HighLevel.TabIndex = 0
        Me.rbYes_HighLevel.Text = "Yes"
        Me.rbYes_HighLevel.UseVisualStyleBackColor = True
        '
        'Panel6
        '
        Me.Panel6.Controls.Add(Me.rbNo_ApplyColor)
        Me.Panel6.Controls.Add(Me.rbYes_ApplyColor)
        Me.Panel6.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel6.Location = New System.Drawing.Point(157, 178)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(169, 29)
        Me.Panel6.TabIndex = 11
        '
        'rbNo_ApplyColor
        '
        Me.rbNo_ApplyColor.AutoSize = True
        Me.rbNo_ApplyColor.Location = New System.Drawing.Point(70, 4)
        Me.rbNo_ApplyColor.Name = "rbNo_ApplyColor"
        Me.rbNo_ApplyColor.Size = New System.Drawing.Size(41, 19)
        Me.rbNo_ApplyColor.TabIndex = 1
        Me.rbNo_ApplyColor.Text = "No"
        Me.rbNo_ApplyColor.UseVisualStyleBackColor = True
        '
        'rbYes_ApplyColor
        '
        Me.rbYes_ApplyColor.AutoSize = True
        Me.rbYes_ApplyColor.Checked = True
        Me.rbYes_ApplyColor.Location = New System.Drawing.Point(13, 5)
        Me.rbYes_ApplyColor.Name = "rbYes_ApplyColor"
        Me.rbYes_ApplyColor.Size = New System.Drawing.Size(42, 19)
        Me.rbYes_ApplyColor.TabIndex = 0
        Me.rbYes_ApplyColor.TabStop = True
        Me.rbYes_ApplyColor.Text = "Yes"
        Me.rbYes_ApplyColor.UseVisualStyleBackColor = True
        '
        'Panel5
        '
        Me.Panel5.Controls.Add(Me.RadioButton9)
        Me.Panel5.Controls.Add(Me.rbYes_PhysicalProperties)
        Me.Panel5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel5.Location = New System.Drawing.Point(157, 143)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(169, 29)
        Me.Panel5.TabIndex = 10
        '
        'RadioButton9
        '
        Me.RadioButton9.AutoSize = True
        Me.RadioButton9.Checked = True
        Me.RadioButton9.Location = New System.Drawing.Point(70, 4)
        Me.RadioButton9.Name = "RadioButton9"
        Me.RadioButton9.Size = New System.Drawing.Size(41, 19)
        Me.RadioButton9.TabIndex = 1
        Me.RadioButton9.TabStop = True
        Me.RadioButton9.Text = "No"
        Me.RadioButton9.UseVisualStyleBackColor = True
        '
        'rbYes_PhysicalProperties
        '
        Me.rbYes_PhysicalProperties.AutoSize = True
        Me.rbYes_PhysicalProperties.Location = New System.Drawing.Point(13, 5)
        Me.rbYes_PhysicalProperties.Name = "rbYes_PhysicalProperties"
        Me.rbYes_PhysicalProperties.Size = New System.Drawing.Size(42, 19)
        Me.rbYes_PhysicalProperties.TabIndex = 0
        Me.rbYes_PhysicalProperties.Text = "Yes"
        Me.rbYes_PhysicalProperties.UseVisualStyleBackColor = True
        '
        'Panel4
        '
        Me.Panel4.Controls.Add(Me.rbNo_InterfernceAnalysis)
        Me.Panel4.Controls.Add(Me.rbYes_InterfernceAnalysis)
        Me.Panel4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel4.Location = New System.Drawing.Point(157, 108)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(169, 29)
        Me.Panel4.TabIndex = 9
        '
        'rbNo_InterfernceAnalysis
        '
        Me.rbNo_InterfernceAnalysis.AutoSize = True
        Me.rbNo_InterfernceAnalysis.Checked = True
        Me.rbNo_InterfernceAnalysis.Location = New System.Drawing.Point(70, 4)
        Me.rbNo_InterfernceAnalysis.Name = "rbNo_InterfernceAnalysis"
        Me.rbNo_InterfernceAnalysis.Size = New System.Drawing.Size(41, 19)
        Me.rbNo_InterfernceAnalysis.TabIndex = 1
        Me.rbNo_InterfernceAnalysis.TabStop = True
        Me.rbNo_InterfernceAnalysis.Text = "No"
        Me.rbNo_InterfernceAnalysis.UseVisualStyleBackColor = True
        '
        'rbYes_InterfernceAnalysis
        '
        Me.rbYes_InterfernceAnalysis.AutoSize = True
        Me.rbYes_InterfernceAnalysis.Location = New System.Drawing.Point(13, 5)
        Me.rbYes_InterfernceAnalysis.Name = "rbYes_InterfernceAnalysis"
        Me.rbYes_InterfernceAnalysis.Size = New System.Drawing.Size(42, 19)
        Me.rbYes_InterfernceAnalysis.TabIndex = 0
        Me.rbYes_InterfernceAnalysis.Text = "Yes"
        Me.rbYes_InterfernceAnalysis.UseVisualStyleBackColor = True
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.rbNo_DrawingViews)
        Me.Panel3.Controls.Add(Me.rbYes_DrawingViews)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel3.Location = New System.Drawing.Point(157, 73)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(169, 29)
        Me.Panel3.TabIndex = 8
        '
        'rbNo_DrawingViews
        '
        Me.rbNo_DrawingViews.AutoSize = True
        Me.rbNo_DrawingViews.Checked = True
        Me.rbNo_DrawingViews.Location = New System.Drawing.Point(70, 4)
        Me.rbNo_DrawingViews.Name = "rbNo_DrawingViews"
        Me.rbNo_DrawingViews.Size = New System.Drawing.Size(41, 19)
        Me.rbNo_DrawingViews.TabIndex = 1
        Me.rbNo_DrawingViews.TabStop = True
        Me.rbNo_DrawingViews.Text = "No"
        Me.rbNo_DrawingViews.UseVisualStyleBackColor = True
        '
        'rbYes_DrawingViews
        '
        Me.rbYes_DrawingViews.AutoSize = True
        Me.rbYes_DrawingViews.Location = New System.Drawing.Point(13, 5)
        Me.rbYes_DrawingViews.Name = "rbYes_DrawingViews"
        Me.rbYes_DrawingViews.Size = New System.Drawing.Size(42, 19)
        Me.rbYes_DrawingViews.TabIndex = 0
        Me.rbYes_DrawingViews.Text = "Yes"
        Me.rbYes_DrawingViews.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(3, 10)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(148, 15)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Higher Level"
        '
        'Label2
        '
        Me.Label2.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(3, 45)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(148, 15)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "*Reports/Parts List"
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.rbNo_ReportPartList)
        Me.Panel2.Controls.Add(Me.rbYes_ReportPartList)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel2.Location = New System.Drawing.Point(157, 38)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(169, 29)
        Me.Panel2.TabIndex = 3
        '
        'rbNo_ReportPartList
        '
        Me.rbNo_ReportPartList.AutoSize = True
        Me.rbNo_ReportPartList.Checked = True
        Me.rbNo_ReportPartList.Location = New System.Drawing.Point(70, 4)
        Me.rbNo_ReportPartList.Name = "rbNo_ReportPartList"
        Me.rbNo_ReportPartList.Size = New System.Drawing.Size(41, 19)
        Me.rbNo_ReportPartList.TabIndex = 1
        Me.rbNo_ReportPartList.TabStop = True
        Me.rbNo_ReportPartList.Text = "No"
        Me.rbNo_ReportPartList.UseVisualStyleBackColor = True
        '
        'rbYes_ReportPartList
        '
        Me.rbYes_ReportPartList.AutoSize = True
        Me.rbYes_ReportPartList.Location = New System.Drawing.Point(13, 5)
        Me.rbYes_ReportPartList.Name = "rbYes_ReportPartList"
        Me.rbYes_ReportPartList.Size = New System.Drawing.Size(42, 19)
        Me.rbYes_ReportPartList.TabIndex = 0
        Me.rbYes_ReportPartList.Text = "Yes"
        Me.rbYes_ReportPartList.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(3, 80)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(148, 15)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "*Drawing Views"
        '
        'Label4
        '
        Me.Label4.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(3, 115)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(148, 15)
        Me.Label4.TabIndex = 5
        Me.Label4.Text = "Interferene Analysis"
        '
        'Label5
        '
        Me.Label5.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(3, 150)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(148, 15)
        Me.Label5.TabIndex = 6
        Me.Label5.Text = "Physical Properties"
        '
        'Label6
        '
        Me.Label6.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(3, 185)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(148, 15)
        Me.Label6.TabIndex = 7
        Me.Label6.Text = "Apply Transperent Color"
        '
        'OccurencePropertiesUpdateForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1063, 591)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Controls.Add(Me.btnUpdateProperties)
        Me.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MinimumSize = New System.Drawing.Size(372, 302)
        Me.Name = "OccurencePropertiesUpdateForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = " Properties Update"
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.TableLayoutPanel1.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel6.ResumeLayout(False)
        Me.Panel6.PerformLayout()
        Me.Panel5.ResumeLayout(False)
        Me.Panel5.PerformLayout()
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents btnUpdateProperties As Button
    Friend WithEvents TableLayoutPanel1 As TableLayoutPanel
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Panel2 As Panel
    Friend WithEvents rbNo_ReportPartList As RadioButton
    Friend WithEvents rbYes_ReportPartList As RadioButton
    Friend WithEvents Panel1 As Panel
    Friend WithEvents rbNo_HighLevel As RadioButton
    Friend WithEvents rbYes_HighLevel As RadioButton
    Friend WithEvents Panel6 As Panel
    Friend WithEvents rbNo_ApplyColor As RadioButton
    Friend WithEvents rbYes_ApplyColor As RadioButton
    Friend WithEvents Panel5 As Panel
    Friend WithEvents RadioButton9 As RadioButton
    Friend WithEvents rbYes_PhysicalProperties As RadioButton
    Friend WithEvents Panel4 As Panel
    Friend WithEvents rbNo_InterfernceAnalysis As RadioButton
    Friend WithEvents rbYes_InterfernceAnalysis As RadioButton
    Friend WithEvents Panel3 As Panel
    Friend WithEvents rbNo_DrawingViews As RadioButton
    Friend WithEvents rbYes_DrawingViews As RadioButton
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
End Class
