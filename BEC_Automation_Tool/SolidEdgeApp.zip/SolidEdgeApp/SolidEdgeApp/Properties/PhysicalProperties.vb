﻿Public Class PhysicalProperties

    Public density As String = String.Empty
    Public accuracy As String = String.Empty
    Public volume As String = String.Empty
    Public area As String = String.Empty
    Public mass As String = String.Empty
    Public relativeAccuracyAchieved As String = String.Empty
    Public status As String = String.Empty
    Public isUserDefined As Boolean = False

End Class
