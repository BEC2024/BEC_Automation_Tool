﻿Public Class MainClass
    Public SolidEdgeinstance As String
End Class
